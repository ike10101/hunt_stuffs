chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.url) {
    console.error('No active tab or URL available.');
    return;
  }

  if (!tab.url.startsWith('https://www.google.com/search')) {
    console.error('This extension only works on Google search pages.');
    return;
  }

  // Parse URL parameters
  const urlParams = new URLSearchParams(new URL(tab.url).search);
  const query = urlParams.get('q') || 'unknown';
  const start = parseInt(urlParams.get('start') || '0', 10);
  const page = Math.floor(start / 10) + 1;

  // Sanitize searchTerm: replace spaces with _, then replace invalid chars with _, collapse multiple _, trim leading/trailing _
  let searchTerm = query.replace(/\s+/g, '_');
  searchTerm = searchTerm.replace(/[^\w-]/g, '_'); // Allow letters, numbers, _, -
  searchTerm = searchTerm.replace(/_+/g, '_'); // Collapse multiple _
  searchTerm = searchTerm.replace(/^_+|_+$/g, ''); // Trim leading/trailing _
  if (!searchTerm) {
    searchTerm = 'unknown';
  }

  const fileName = `${searchTerm}_page_${page}.txt`;

  // Send message to content script to extract URLs
  chrome.tabs.sendMessage(tab.id, { action: 'extractUrls' }, (response) => {
    if (chrome.runtime.lastError || !response || !response.urls) {
      console.error('Failed to extract URLs:', chrome.runtime.lastError);
      return;
    }

    const uniqueUrls = [...new Set(response.urls)]; // Ensure uniqueness
    if (uniqueUrls.length === 0) {
      console.log('No URLs found on this page.');
      return;
    }

    const fileContent = uniqueUrls.join('\n') + '\n'; // One URL per line

    // Create Blob
    const blob = new Blob([fileContent], { type: 'text/plain' });

    // Use FileReader to convert to data URL (since URL.createObjectURL isn't available in service workers)
    const reader = new FileReader();
    reader.onload = function() {
      const dataUrl = reader.result;
      chrome.downloads.download({
        url: dataUrl,
        filename: fileName,
        saveAs: false // Auto-save to downloads folder
      });
    };
    reader.onerror = function() {
      console.error('Failed to read blob as data URL:', reader.error);
    };
    reader.readAsDataURL(blob);
  });
});