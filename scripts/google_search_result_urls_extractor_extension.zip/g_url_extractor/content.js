chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractUrls') {
    // More robust selector: links in #search that contain an h3 child (organic results)
    const urlElements = document.querySelectorAll('#search a:has(> h3)');
    const urls = Array.from(urlElements)
      .map(a => a.href)
      .filter(href => href && href.startsWith('http') && !href.includes('google.com') && !href.startsWith('https://www.google.com/')); // Filter out non-results, Google internal, or tracking links

    // Deduplicate using Set
    const uniqueUrls = [...new Set(urls)];

    // Optional: Log for debugging (view in console)
    console.log('Extracted unique URLs:', uniqueUrls);

    // Send back the URLs
    sendResponse({ urls: uniqueUrls });
  }
  return true; // Keep the message channel open for async response
});